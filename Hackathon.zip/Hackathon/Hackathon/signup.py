import pymongo
from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__, template_folder='templates')
client = pymongo.MongoClient('mongodb://localhost:27017')
db = client['bus']  # Replace 'your_database_name' with the actual database name
collection = db['admin']  # Replace 'your_collection_name' with the actual collection name

@app.route('/')
def index():
    return render_template('signup.html')

@app.route('/signup', methods=['POST'])
def signup():
    admin_id = request.form['admin_id']
    email = request.form['email']
    name = request.form['name']
    password = request.form['password']

    # Check if the admin ID already exists in the collection
    if collection.find_one({'admin_id': admin_id}):
        return 'Admin ID already exists. Please choose a different one.'

    # Check if the email already exists in the collection
    if collection.find_one({'email': email}):
        return 'Email already exists. Please choose a different one.'

    # Insert the user information into the collection
    user = {
        'admin_id': admin_id,
        'email': email,
        'name': name,
        'password': password
    }
    collection.insert_one(user)

    return 'Signup successful!'

if __name__ == '__main__':
    app.run()
