import cv2
from pyzbar.pyzbar import decode
from pymongo import MongoClient
import pyttsx3
import pymongo
from flask import Flask, render_template, request, redirect, url_for, session
from flask_session import Session
import secrets
import time
from bson.objectid import ObjectId


# app = Flask(__name__)
# client = pymongo.MongoClient('mongodb://localhost:27017')
# db = client['bus']
# collection_admin = db['admin']
# collection_announcement = db['announcement']
# collection_information = db['information']

# @app.route('/')
# def index():
#     return render_template('departure.html')

# @app.route('/exitannounce', methods=['POST'])
# def exitannounce():
#     train_number = request.form['train_number']
#     platform = request.form['platform']
#     time_exit= request.form['time_exit']

#     announcement_text2 = f"Attention! Bus number {train_number} is departing from platform number {platform} at {time_exit}."
#     engine = pyttsx3.init()
#     engine.say(announcement_text2)
#     engine.runAndWait()

#     return ''


# if __name__ == '__main__':
#     app.run()


# from flask import Flask, render_template, request
# from pymongo import MongoClient

app = Flask(__name__)

# MongoDB connection setup
client = MongoClient('mongodb://localhost:27017/')
db = client['bus']
collection = db['announcement']

@app.route('/')
def display_data():
    # Fetch all documents from the collection
    data = list(collection.find())  # Convert the cursor to a list

    # Render the template with the fetched data
    return render_template('departure.html', bus_info=data)
    
@app.route('/exitannounce', methods=['POST'])
def exitannounce():
    train_number = request.form['train_number']
    platform = request.form['platform']
    time_exit= request.form['time_exit']

    announcement_text2 = f"Attention! Bus number {train_number} is departing from platform number {platform} at {time_exit}."
    engine = pyttsx3.init()
    engine.say(announcement_text2)
    engine.runAndWait()

    return ''


if __name__ == '__main__':
     app.run()
