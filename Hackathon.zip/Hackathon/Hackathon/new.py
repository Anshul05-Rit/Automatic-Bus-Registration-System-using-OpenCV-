from flask import Flask, render_template, redirect, request
from pymongo import MongoClient
from bson.objectid import ObjectId

app = Flask(__name__)
client = MongoClient('mongodb://localhost:27017')
db = client['bus']
collection = db['announcement']

@app.route('/')
def index():
    # Retrieve all documents from the MongoDB collection
    documents = list(collection.find())
    return render_template('index.html', documents=documents)

@app.route('/edit/<id>')
def edit_info(id):
    # Retrieve the document with the specified ID from the MongoDB collection
    document = collection.find_one({'_id': ObjectId(id)})
    return render_template('edit.html', document=document)

# @app.route('/update', methods=['POST'])
# def update():
#     # Retrieve the updated information from the form
#     id = request.form['id']
#     train_number = request.form['train_number']
#     departure = request.form['departure']
#     platform = request.form['platform']
#     time_exit = request.form['time_exit']

#     # Update the document in the MongoDB collection
#     collection.update_one({'_id': ObjectId(id)}, {'$set': {
#         'train_number': train_number,
#         'departure': departure,
#         'platform': platform,
#         'time_exit': time_exit
#     }})

#     return redirect('/')

# @app.route('/delete/<id>')
# def delete(id):
#     # Delete the document with the specified ID from the MongoDB collection
#     collection.delete_one({'_id': ObjectId(id)})
#     return redirect('/')

# if __name__ == '__main__':
#     app.run()

@app.route('/update', methods=['POST'])
def update():
    # Retrieve the updated information from the form
    id = request.form['id']
    train_number = request.form['train_number']
    departure = request.form['departure']
    platform = request.form['platform']
    time_exit = request.form['time_exit']

    # Retrieve the document from the MongoDB collection
    document = collection.find_one({'_id': ObjectId(id)})

    # Update the document in the MongoDB collection
    collection.update_one({'_id': ObjectId(id)}, {'$set': {
        'train_number': train_number or document['train_number'],
        'departure': departure or document['departure'],
        'platform': platform or document['platform'],
        'time_exit': time_exit or document['time_exit']
    }})

    return redirect('/')

# @app.route('/delete/<id>')
# def delete(id):
#     # Delete the document with the specified ID from the MongoDB collection
#     collection.delete_one({'_id': ObjectId(id)})
#     return redirect('/')

@app.route('/delete/<id>')
def delete_info(id):
    # Delete the document with the specified ID from the MongoDB collection
    collection.delete_one({'_id': ObjectId(id)})
    return redirect('/')


# from flask import Flask, render_template, redirect, request
# from pymongo import MongoClient
# from bson.objectid import ObjectId

# app = Flask(__name__)
# client = MongoClient('mongodb://localhost:27017')
# db = client['bus']
# collection = db['announcement']

# @app.route('/')
# def index():
#     # Retrieve all documents from the MongoDB collection
#     documents = list(collection.find())
#     return render_template('index.html', documents=documents)

# @app.route('/edit/<id>')
# def edit(id):
#     # Retrieve the document with the specified ID from the MongoDB collection
#     document = collection.find_one({'_id': ObjectId(id)})
#     return render_template('edit.html', document=document)

# @app.route('/update', methods=['POST'])
# def update():
#     # Retrieve the updated information from the form
#     id = request.form['id']
#     train_number = request.form['train_number']
#     departure = request.form['departure']
#     platform = request.form['platform']
#     time_exit = request.form['time_exit']

#     # Update the document in the MongoDB collection
#     collection.update_one({'_id': ObjectId(id)}, {'$set': {
#         'train_number': train_number,
#         'departure': departure,
#         'platform': platform,
#         'time_exit': time_exit
#     }})

#     return redirect('/')

# @app.route('/delete/<id>')
# def delete(id):
#     # Delete the document with the specified ID from the MongoDB collection
#     collection.delete_one({'_id': ObjectId(id)})
#     return redirect('/')

if __name__ == '__main__':
    app.run()
