import cv2
from pyzbar.pyzbar import decode
from pymongo import MongoClient
from flask import Flask, render_template, request

app = Flask(__name__)
client = MongoClient('mongodb://localhost:27017')
db = client['bus']

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/detect_qr', methods=['POST'])
def detect_qr():
    # Initialize the camera
    cap = cv2.VideoCapture(0)

    # Variable to keep track of detected QR codes
    detected_qr_codes = set()

    while True:
        # Read frame from the camera
        ret, frame = cap.read()

        # Detect QR codes in the frame
        decoded_objects = decode(frame)

        # Process each detected QR code
        for obj in decoded_objects:
            # Extract QR code data as string
            qr_data = obj.data.decode('utf-8')

            # Check if QR code has been detected before
            if qr_data not in detected_qr_codes:
                # Add the QR code to the set of detected codes
                detected_qr_codes.add(qr_data)

                # Print the QR code data
                print("QR Code Detected: ", qr_data)

                # Check if the bus number is in the database
                collection = db['announcement']
                bus_info = collection.find_one({'train_number': qr_data})
                if bus_info:
                    bus_number = bus_info['train_number']
                    return f"Matching Bus Number: {bus_number}"
                else:
                    return "No matching bus number found."

        # Display the frame
        cv2.imshow("QR Code Detection", frame)

        # Check for 'q' key press to exit
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Release the camera and close windows
    cap.release()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    app.run()
