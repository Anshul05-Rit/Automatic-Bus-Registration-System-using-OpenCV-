# from flask import Flask, render_template
# from pymongo import MongoClient

# app = Flask(__name__)

# # MongoDB connection setup
# client = MongoClient('mongodb://localhost:27017/')
# db = client['bus']
# collection = db['information']

# @app.route('/')
# def display_data():
#     # Fetch all documents from the collection
#     data = collection.find()

#     # Render the template with the fetched data
#     return render_template('row.html', data=data)

from flask import Flask, render_template, redirect, request
from pymongo import MongoClient
from bson.objectid import ObjectId

app = Flask(__name__)
client = MongoClient('mongodb://localhost:27017')
db = client['bus']
collection = db['announcement']

@app.route('/')
def index():
    # Retrieve all documents from the MongoDB collection
    documents = list(collection.find())
    return render_template('records.html', documents=documents)

if __name__ == '__main__':
    app.run()
