from flask import Flask, render_template, request
from pymongo import MongoClient

app = Flask(__name__)
client = MongoClient('mongodb://localhost:27017')
db = client['bus']
collection = db['announcement']

@app.route('/')
def index():
    return render_template('bus_registration.html')

@app.route('/save_announcement', methods=['POST'])
def save_announcement():
    train_number = request.form['train_number']
    departure = request.form['departure']
    platform = request.form['platform']


    # Create a document to be inserted in MongoDB
    document = {
        'train_number': train_number,
        'departure': departure,
        'platform': platform
    }

    # Insert the document into the MongoDB collection
    collection.insert_one(document)

    return """
        <script>
            alert('Information saved successfully!');
            window.location.href = '/';
        </script>
         """

if __name__ == '__main__':
    app.run()
