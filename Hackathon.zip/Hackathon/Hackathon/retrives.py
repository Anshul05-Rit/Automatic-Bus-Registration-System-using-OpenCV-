from flask import Flask, render_template, request
from pymongo import MongoClient
import pyttsx3

app = Flask(__name__)

# Establish a connection to MongoDB
client = MongoClient('mongodb://localhost:27017')
db = client['bus']
collection = db['announcement']

# Route for the home page
@app.route('/')
def home():
    return render_template('announcement.html')

# Route for handling form submission and making the announcement
# @app.route('/announce', methods=['POST'])
# def announce():
#     train_number = request.form['train_number']
    
#     # Retrieve train information from MongoDB
#     document = collection.find_one({'train_number': train_number})
#     if document:
#         departure = document['departure']
#         time = document['time']
        
#         # Make the announcement
#         announcement_text = f"Attention! Train number {train_number} departing from {departure} at {time}."
#         engine = pyttsx3.init()
#         engine.say(announcement_text)
#         engine.runAndWait()

#         return render_template('announcement.html', announcement_text=announcement_text)
#     else:
#         return render_template()
# Route for handling form submission and making the announcement
@app.route('/announce', methods=['POST'])
def announce():
    train_number = request.form['train_number']

    # Retrieve train information from MongoDB
    document = collection.find_one({'train_number': train_number})
    if document:
        departure = document['departure']
        time = document['time']

        # Make the announcement
        announcement_text = f"Attention! Train number {train_number} departing from {departure} at {time}."
        print(announcement_text)

        # Print available voices on your system
        engine = pyttsx3.init()
        voices = engine.getProperty('voices')
        for voice in voices:
            print(voice.id, voice.name)

        engine.say(announcement_text)
        engine.runAndWait()

        return render_template('announcement.html', announcement_text=announcement_text)
    else:
        return render_template('announcement.html')
if __name__ == '__main__':
    app.run()

